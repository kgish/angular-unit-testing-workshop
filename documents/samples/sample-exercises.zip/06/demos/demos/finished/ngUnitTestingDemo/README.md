# Pluralsight's Unit Testing in Angular Course
This course is up to date.

To get started, clone the repo or download it

npm install
npm test